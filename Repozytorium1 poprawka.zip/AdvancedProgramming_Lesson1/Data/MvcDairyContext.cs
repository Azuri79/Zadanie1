﻿using AdvancedProgramming_Lesson1.Models;
using Microsoft.EntityFrameworkCore;

namespace AdvancedProgramming_Lesson1.Data
{
    public class MvcDairyContext : DbContext
    {
        public MvcDairyContext(DbContextOptions<MvcDairyContext> options)
        : base(options)
        {
        }
        public DbSet<Dairy> Dairy { get; set; }
    }
}
