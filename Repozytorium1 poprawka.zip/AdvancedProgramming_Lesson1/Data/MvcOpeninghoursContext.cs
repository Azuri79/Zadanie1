﻿using AdvancedProgramming_Lesson1.Models;
using Microsoft.EntityFrameworkCore;

namespace AdvancedProgramming_Lesson1.Data
{
    public class MvcOpeninghoursContext : DbContext
    {
        public MvcOpeninghoursContext(DbContextOptions<MvcOpeninghoursContext> options)
        : base(options)
        {
        }
        public DbSet<Openinghours> Openinghours { get; set; }
    }
}
