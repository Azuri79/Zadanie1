﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdvancedProgramming_Lesson1.Data;
using AdvancedProgramming_Lesson1.Models;

namespace AdvancedProgramming_Lesson1.Controllers
{
    public class OpeninghoursController : Controller
    {
        private readonly MvcOpeninghoursContext _context;

        public OpeninghoursController(MvcOpeninghoursContext context)
        {
            _context = context;
        }

        // GET: Openinghours
        public async Task<IActionResult> Index()
        {
            return View(await _context.Openinghours.ToListAsync());
        }

        // GET: Openinghours/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var openinghours = await _context.Openinghours
                .FirstOrDefaultAsync(m => m.Id == id);
            if (openinghours == null)
            {
                return NotFound();
            }

            return View(openinghours);
        }

        // GET: Openinghours/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Openinghours/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Weekday,OpeningTime,ClosingTime,Duration,People")] Openinghours openinghours)
        {
            if (ModelState.IsValid)
            {
                _context.Add(openinghours);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(openinghours);
        }

        // GET: Openinghours/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var openinghours = await _context.Openinghours.FindAsync(id);
            if (openinghours == null)
            {
                return NotFound();
            }
            return View(openinghours);
        }

        // POST: Openinghours/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Weekday,OpeningTime,ClosingTime,Duration,People")] Openinghours openinghours)
        {
            if (id != openinghours.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(openinghours);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OpeninghoursExists(openinghours.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(openinghours);
        }

        // GET: Openinghours/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var openinghours = await _context.Openinghours
                .FirstOrDefaultAsync(m => m.Id == id);
            if (openinghours == null)
            {
                return NotFound();
            }

            return View(openinghours);
        }

        // POST: Openinghours/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var openinghours = await _context.Openinghours.FindAsync(id);
            _context.Openinghours.Remove(openinghours);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OpeninghoursExists(int id)
        {
            return _context.Openinghours.Any(e => e.Id == id);
        }
    }
}
